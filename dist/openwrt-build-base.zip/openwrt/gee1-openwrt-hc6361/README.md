openwrt-hc6361
==============

Generate HiWiFi HC6361 (tw150v1) firmware with OpenWrt code

#### 固件编译方法

    git clone https://github.com/rssnsj/openwrt-hc6361.git
    cd openwrt-hc6361
    make
